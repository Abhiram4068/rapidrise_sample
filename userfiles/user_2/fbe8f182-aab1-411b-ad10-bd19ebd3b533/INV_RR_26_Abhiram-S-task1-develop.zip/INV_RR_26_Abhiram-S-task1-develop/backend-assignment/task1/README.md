# TASK-1  ASSIGNMENT – Django REST API

This project is a Django REST Framework based API that provides:

- JWT-based authentication
- Task management (CRUD operations)
- Secure file upload and download using tokenized links

The system demonstrates secure API design, authentication workflows, and controlled file access.

---

# Features

### Authentication
- User registration
- Login with JWT authentication
- Token refresh
- Logout with refresh token blacklist

### Task Management
- Create tasks
- List tasks
- Retrieve task details
- Update tasks
- Delete tasks

### File Management
- Upload files
- List uploaded files
- Generate secure download links
- Download files using tokenized URLs

---

# Tech Stack

- Python
- Django
- Django REST Framework
- SimpleJWT
- SQLite

---

# Project Structure

```
backend-assignment/
│
├── task1/
│   │
│   ├── config/                # Django project configuration
│   │   ├── settings.py
│   │   ├── urls.py
│   │
│   ├── resources/             # Main application
│   │   ├── models.py
│   │   ├── serializers.py
│   │   ├── views.py
│   │   ├── services.py
│   │   ├── urls.py
│   │
│   ├── uploadedFiles/         # Uploaded files storage
│   │
│   ├── manage.py
│   ├── db.sqlite3
│   ├── .env
│   ├── requirements.txt
│   └── venv/
│
├── task2/                     # Second assignment module
│
└── README.md
```

---

# Installation Guide

## 1. Clone the Repository

```bash
git clone <repository-url>
cd backend-assignment/task1
```

---

# 2. Create Virtual Environment

```bash
python -m venv venv
```

Activate the environment.

Linux / Mac

```bash
source venv/bin/activate
```

Windows

```bash
venv\Scripts\activate
```

---

# 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

# 4. Setup Environment Variables

Create a `.env` file inside **task1**.

Example:

```
SECRET_KEY=your_secret_key
DEBUG=True

ACCESS_TOKEN_LIFETIME=15
REFRESH_TOKEN_LIFETIME=7

```
---

# 5. Apply Migrations

```bash
python manage.py migrate
```

---

# 6. Run the Server

```bash
python manage.py runserver
```

Server will start at:

```
http://127.0.0.1:8000
```

---

# Authentication Flow

```
User Login
   ↓
Server validates credentials
   ↓
Access Token + Refresh Token generated
   ↓
Client sends Access Token in Authorization header
   ↓
Protected APIs accessed
```

Example Authorization header:

```
Authorization: Bearer <access_token>
```

---

# API Endpoints

Base URL

```
/api/
```

---

# Authentication APIs

```
POST /api/auth/register/
POST /api/auth/login/
POST /api/auth/refresh/
POST /api/auth/logout/
```

| Endpoint | Description |
|--------|-------------|
| Register | Creates a new user |
| Login | Returns access and refresh tokens |
| Refresh | Generates new access token |
| Logout | Blacklists refresh token |

---

# Task APIs

```
GET    /api/task/
POST   /api/task/

GET    /api/task/{id}/
PUT    /api/task/{id}/update/
DELETE /api/task/{id}/delete/
```

These APIs allow users to manage their tasks.

---

# File APIs

```
POST /api/files/
GET  /api/files/

POST /api/files/{uuid}/token-generate/
GET  /api/files/{token}/download/
```

---

# Secure File Download Flow

```
Client uploads file
      ↓
File stored on server
      ↓
User requests download link
      ↓
Server generates secure token
      ↓
User downloads file using token
      ↓
Server validates token and serves file
```

This prevents exposing the actual file path and improves security.

---

# Running Tests

```bash
python manage.py test
```

---

# Environment Configuration

The project uses **python-dotenv** to manage environment variables.

Sensitive configurations such as:

- SECRET_KEY
- DEBUG
- JWT token lifetimes

are stored in `.env` instead of being hardcoded in `settings.py`.

---



# Author

Abhiram S