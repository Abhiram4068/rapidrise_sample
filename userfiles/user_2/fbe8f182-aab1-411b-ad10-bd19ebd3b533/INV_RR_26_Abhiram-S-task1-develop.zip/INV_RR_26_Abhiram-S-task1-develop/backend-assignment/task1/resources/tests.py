from django.urls import reverse
from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Task
from django.core.files.uploadedfile import SimpleUploadedFile
from resources.models import File, FileDownloadToken
from django.utils import timezone
from datetime import timedelta

User = get_user_model()

class AuthAPITestCase(APITestCase):

    def setUp(self):
        """
        Create a user for authentication related tests.
        """
        self.user = User.objects.create_user(
             username="testuser",
        password="StrongPass123!",
        first_name="Test",
        last_name="User"
        )

        self.register_url = reverse("resources:user-register")
        self.login_url = reverse("resources:user-login")
        self.refresh_url = reverse("resources:token_refresh")
        self.logout_url = reverse("resources:user-logout")

    def test_user_registration(self):
        data = {
            "username": "newuser",
        "password": "StrongPass123!",
        "confirm_password": "StrongPass123!",
        "first_name": "New",
        "last_name": "User"
        }

        response = self.client.post(self.register_url, data)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["message"], "User registered successfully")
        self.assertTrue(User.objects.filter(username="newuser").exists())

    def test_user_login(self):
        data = {
            "username": "testuser",
            "password": "StrongPass123!"
        }

        response = self.client.post(self.login_url, data)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["message"], "Login successful")

        self.assertIn("tokens", response.data)
        self.assertIn("access", response.data["tokens"])
        self.assertIn("refresh", response.data["tokens"])

    def test_login_invalid_credentials(self):
        data = {
            "username": "testuser",
            "password": "wrongpassword"
        }

        response = self.client.post(self.login_url, data)

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
    
    def test_token_refresh(self):
        login_data = {
            "username": "testuser",
            "password": "StrongPass123!"
        }

        login_response = self.client.post(self.login_url, login_data)
        refresh_token = login_response.data["tokens"]["refresh"]

        response = self.client.post(
        self.refresh_url,
        {"refresh": refresh_token},
        format="json"
    )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("access", response.data)
    def test_user_logout(self):
        login_data = {
            "username": "testuser",
            "password": "StrongPass123!"
        }

        login_response = self.client.post(self.login_url, login_data)
        refresh_token = login_response.data["tokens"]["refresh"]
        access_token = login_response.data["tokens"]["access"]

        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {access_token}")

        response = self.client.post(self.logout_url, {
            "refresh": refresh_token
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["message"], "Logout successful")
    def test_logout_without_authentication(self):
        login_data = {
            "username": "testuser",
            "password": "StrongPass123!"
        }

        login_response = self.client.post(self.login_url, login_data)
        refresh_token = login_response.data["tokens"]["refresh"]

        response = self.client.post(self.logout_url, {
            "refresh": refresh_token
        })

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
    def test_register_existing_username(self):
        data = {
           "username": "testuser",
        "password": "StrongPass123!",
        "confirm_password": "StrongPass123!",
        "first_name": "Test",
        "last_name": "User"
        }

        response = self.client.post(self.register_url, data)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

class TaskAPITestCase(APITestCase):

    def setUp(self):
        """
        Create two users for testing ownership and permissions.
        """
        self.user = User.objects.create_user(
            username="user1",
            password="StrongPass123!"
        )

        self.other_user = User.objects.create_user(
            username="user2",
            password="StrongPass123!"
        )

        self.client.force_authenticate(user=self.user)

        # Create a task for user1
        self.task = Task.objects.create(
            title="Initial Task",
            description="Test Description",
            created_by=self.user
        )

    def test_create_task(self):
        url = reverse("resources:task-create-list")

        data = {
            "title": "New Task",
            "description": "New Description"
        }

        response = self.client.post(url, data)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["task"]["title"], "New Task")
        self.assertEqual(Task.objects.count(), 2)


    def test_list_tasks(self):
        url = reverse("resources:task-create-list")

        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(len(response.data["tasks"]), 1)



    def test_get_task_detail(self):
        url = reverse("resources:task-detail", kwargs={"pk": self.task.id})

        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["task"]["id"], self.task.id)

    def test_cannot_access_other_users_task(self):
        other_task = Task.objects.create(
            title="Other Task",
            description="Other Description",
            created_by=self.other_user
        )

        url = reverse("resources:task-detail", kwargs={"pk": other_task.id})
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


    def test_update_task(self):
        url = reverse("resources:task-update", kwargs={"pk": self.task.id})

        data = {
            "title": "Updated Title",
            "is_completed": True
        }

        response = self.client.put(url, data)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["task"]["title"], "Updated Title")

        self.task.refresh_from_db()
        self.assertTrue(self.task.is_completed)


    def test_delete_task(self):
        url = reverse("resources:task-delete", kwargs={"pk": self.task.id})

        response = self.client.delete(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(Task.objects.count(), 0)


    def test_unauthenticated_access(self):
        self.client.force_authenticate(user=None)

        url = reverse("resources:task-create-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)


class FileAPITestCase(APITestCase):

    def setUp(self):
        """
        Setup authenticated user and URLs for file API tests.
        """

        self.user = User.objects.create_user(
            username="fileuser",
            password="StrongPass123!"
        )

        self.other_user = User.objects.create_user(
            username="otheruser",
            password="StrongPass123!"
        )

        self.client.force_authenticate(user=self.user)

        self.upload_url = reverse("resources:file-upload")

        self.test_file = SimpleUploadedFile(
            "testfile.pdf",
            b"dummy file content",
            content_type="application/pdf"
        )

   

    def test_file_upload(self):
        """
        Test uploading a single file.
        """

        data = {
            "files": [self.test_file]
        }

        response = self.client.post(
            self.upload_url,
            data,
            format="multipart"
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["message"], "Files uploaded successfully")

        self.assertEqual(len(response.data["files"]), 1)
        self.assertEqual(File.objects.count(), 1)



    def test_list_files(self):
        """
        Ensure authenticated user can list their uploaded files.
        """

        File.objects.create(
            file=self.test_file,
            name="testfile.pdf",
            content_type="application/pdf",
            size=self.test_file.size,
            uploaded_by=self.user
        )

        response = self.client.get(self.upload_url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)



    def test_generate_download_link(self):
        """
        Test generating a secure download link for a file.
        """

        file_instance = File.objects.create(
            file=self.test_file,
            name="testfile.pdf",
            content_type="application/pdf",
            size=self.test_file.size,
            uploaded_by=self.user
        )

        url = reverse(
            "resources:file-link",
            kwargs={"pk": file_instance.id}
        )

        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertIn("download_url", response.data)
        self.assertIn("expires_at", response.data)

        self.assertEqual(FileDownloadToken.objects.count(), 1)


    def test_download_file_with_token(self):
        """
        Test downloading a file using a valid token.
        """

        file_instance = File.objects.create(
            file=self.test_file,
            name="testfile.pdf",
            content_type="application/pdf",
            size=self.test_file.size,
            uploaded_by=self.user
        )

        token = FileDownloadToken.objects.create(
            file=file_instance,
            user=self.user,
            token="validtoken123",
            expires_at=timezone.now() + timedelta(minutes=5)
        )

        url = reverse(
            "resources:file-download",
            kwargs={"token": token.token}
        )

        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)



    def test_cannot_generate_link_for_other_users_file(self):
        """
        Ensure a user cannot generate download links for files
        uploaded by another user.
        """

        file_instance = File.objects.create(
            file=self.test_file,
            name="testfile.pdf",
            content_type="application/pdf",
            size=self.test_file.size,
            uploaded_by=self.other_user
        )

        url = reverse(
            "resources:file-link",
            kwargs={"pk": file_instance.id}
        )

        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


    def test_expired_download_token(self):
        """
        Ensure expired download tokens cannot be used.
        """

        file_instance = File.objects.create(
            file=self.test_file,
            name="testfile.pdf",
            content_type="application/pdf",
            size=self.test_file.size,
            uploaded_by=self.user
        )

        token = FileDownloadToken.objects.create(
            file=file_instance,
            user=self.user,
            token="expiredtoken",
            expires_at=timezone.now() - timedelta(minutes=1)
        )

        url = reverse(
            "resources:file-download",
            kwargs={"token": token.token}
        )

        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

 

    def test_token_can_only_be_used_once(self):
        """
        Ensure download token cannot be reused.
        """

        file_instance = File.objects.create(
            file=self.test_file,
            name="testfile.pdf",
            content_type="application/pdf",
            size=self.test_file.size,
            uploaded_by=self.user
        )

        token = FileDownloadToken.objects.create(
            file=file_instance,
            user=self.user,
            token="onetimetoken",
            expires_at=timezone.now() + timedelta(minutes=5)
        )

        url = reverse(
            "resources:file-download",
            kwargs={"token": token.token}
        )

        # First download
        response1 = self.client.get(url)
        self.assertEqual(response1.status_code, status.HTTP_200_OK)

        # Second download should fail
        response2 = self.client.get(url)
        self.assertEqual(response2.status_code, status.HTTP_403_FORBIDDEN)


    def test_upload_requires_authentication(self):
        """
        Ensure file upload requires authentication.
        """

        self.client.force_authenticate(user=None)

        data = {
            "files": [self.test_file]
        }

        response = self.client.post(
            self.upload_url,
            data,
            format="multipart"
        )

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)