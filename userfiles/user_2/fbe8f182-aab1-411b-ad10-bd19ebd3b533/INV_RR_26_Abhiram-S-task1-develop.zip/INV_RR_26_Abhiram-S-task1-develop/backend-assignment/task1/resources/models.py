from django.db import models
from django.contrib.auth.models import AbstractUser
import uuid

class User(AbstractUser):
    class Meta:
        db_table='accounts'

class Task(models.Model):
    title=models.CharField(max_length=255)
    description = models.TextField(blank=True)
    is_completed = models.BooleanField(default=False)
    created_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="tasks"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table='MyTasks'
        
    def __str__(self):
        return self.title
    


def upload_to_user_directory(instance, filename):
    return f"uploadedfiles/user_{instance.uploaded_by.id}/{filename}"

class File(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    file = models.FileField(upload_to=upload_to_user_directory)
    name = models.CharField(max_length=255)
    content_type = models.CharField(max_length=100)
    size = models.PositiveBigIntegerField()
    uploaded_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="files",
        db_index=True
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        db_table="MyFiles"

    def __str__(self):
        return f"{self.name} ({self.uploaded_by.username})"
    

class FileDownloadToken(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    file = models.ForeignKey(
        File,
        on_delete=models.CASCADE,
        related_name="download_tokens"
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="download_tokens"
    )
    token = models.CharField(max_length=64, unique=True)
    expires_at = models.DateTimeField()
    is_accessed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table="FileShareTokens"

        indexes = [
            models.Index(fields=["token"]),
        ]
