from rest_framework.views import APIView
from rest_framework import status
from rest_framework.response import Response
from .serializers import RegisterSerializer, LoginSerializer, LogoutSerializer, TaskCreateSerializer, TaskListSerializer, TaskUpdateSerializer, FileUploadSerializer, FileListSerializer
from rest_framework.permissions import AllowAny, IsAuthenticated
from .services import UserAuthService, TaskService, FileService
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.http import FileResponse, Http404
from django.urls import reverse
import uuid
from rest_framework.exceptions import NotFound

class RegisterView(APIView):
    """
        API view for handling user registration.
    """
    authentication_classes=[]
    permission_classes=[AllowAny]
    
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = UserAuthService.user_register(serializer.validated_data)

        return Response(
            {
                "message": "User registered successfully",
                "user_id": user.id
            },
            status=status.HTTP_201_CREATED
        )



class LoginView(APIView):
    """
        API view for user authentication.
    """
    permission_classes=[AllowAny]
    authentication_classes=[]
    
    def post(self, request):
        serializer=LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        result=UserAuthService.user_login(
            serializer.validated_data['username'],
            serializer.validated_data['password']
        )

        user=result['user']
        tokens=result['tokens']
        return Response(
            {'message':'Login successful',
             'user':{
                 'id':user.id,
                 'first_name':user.first_name
             },
             'tokens':tokens
             },
            
            status=status.HTTP_200_OK
        )
        
class LogoutView(APIView):
    """
        API view for logging out authenticated users.
    """
    authentication_classes=[JWTAuthentication]
    permission_classes=[IsAuthenticated]
    
    def post(self, request):
        serializer=LogoutSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        refresh=serializer.validated_data['refresh']
        UserAuthService.user_logout(refresh)
        return Response(
            {'message':'Logout successful'},
             status=status.HTTP_200_OK
        )
        
class TaskListCreateView(APIView):
    """
    Handles creating a new task and listing tasks for the authenticated user.
    """
    permission_classes=[IsAuthenticated]
    
    def post(self, request):
        """
        Creates a new task for the logged-in user.

        """
        
        serializer=TaskCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        task=TaskService.create_task(request.user, serializer.validated_data)
        
        return Response(
        {
            "message": "Task created successfully",
            "task": {
                "id": task.id,
                "title": task.title
            }
        },
        status=status.HTTP_201_CREATED
        )
        
        
    def get(self, request):
        """
        Returns all active tasks for the logged-in user.
        """
        tasks=TaskService.task_by_user(request.user)
        if not tasks.exists():
            return Response(
                {'message':'You havent uploaded any tasks yet'},
                status=status.HTTP_200_OK
            )
        serializer = TaskListSerializer(tasks, many=True)
        return Response(
            {
            "count": tasks.count(),
            'tasks':serializer.data
            }
        )
        
        
class TaskDetailView(APIView):
    """
    Retrieves detailed information about a single task.
    """
    permission_classes=[IsAuthenticated]
     
    def get(self, request, pk):
        """
        Fetches a specific task belonging to the authenticated user.
        """
        tasks=TaskService.task_detail(request.user, pk)
        serializer=TaskListSerializer(tasks, many=False)
        return Response(
            {
                "task": {
                    "id": serializer.data["id"],
                    "title": serializer.data["title"],
                    "description": serializer.data["description"],
                    "is_completed": serializer.data["is_completed"],
                    "created_by": serializer.data["created_by"],
                    "created_at": serializer.data["created_at"]
                }
            },
            status=status.HTTP_200_OK
        )
        
class TaskUpdateView(APIView):
    """
    Handles updating an existing task.
    """
    permission_classes=[IsAuthenticated]
    
    def put(self, request, pk):
        """
        Updates task fields for the given task ID.
        """
        task_obj=TaskService.task_detail(request.user, pk)
        serializer=TaskUpdateSerializer(task_obj, data=request.data, partial = True)
        serializer.is_valid(raise_exception=True)
        task=TaskService.update_task(task_obj, serializer.validated_data)
        return Response(
            {
                "message": "Task updated successfully",
                "task": {
                    "id": task.id,
                    "title": task.title,
                    "description": task.description,
                    "is_completed": task.is_completed
                }
            },
            status=status.HTTP_200_OK
        )
    
class TaskDeleteView(APIView):
    """
    Handles deletion of a task.
    
    """
    permission_classes = [IsAuthenticated]
    def delete(self, request, pk):
        """
        Deletes a task owned by the authenticated user.
        """
        task = TaskService.task_detail(request.user, pk)

        TaskService.delete_task(task)

        return Response(
            {"message": "Task deleted successfully"},
            status=status.HTTP_200_OK
        )
    

class FileListUploadView(APIView):
    """
    Handles file upload and file listing for the authenticated user.
    """
    permission_classes = [IsAuthenticated]
    def post(self, request):
        print(request.data)
        serializer=FileUploadSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        files = serializer.validated_data["files"]

        file_instances=FileService.upload_files(
            request.user,
            files
        )
        return Response(
            {
                "message": "Files uploaded successfully",
                "files": [
                    {
                        "id": f.id,
                        "name": f.name,
                        "size": f.size,
                        "content_type": f.content_type
                    }
                    for f in file_instances
                ]
            },
            status=status.HTTP_201_CREATED
        )
    def get(self, request):
        files=FileService.list_files(request.user)
        if not files.exists():
            return Response({
                "message": "No files uploaded yet"
            })
        serializer=FileListSerializer(files, many=True)
        return Response(serializer.data)
    

class FileLinkView(APIView):
    """
    Generates a secure, time-limited download link for a file
    owned by the authenticated user.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            pk = uuid.UUID(pk)
        except ValueError:
            raise NotFound("File not found")
        file_obj = FileService.get_file_by_user(request.user, pk)

        token_obj = FileService.generate_download_token(
            request.user,
            file_obj
        )

        download_path = reverse(
            "resources:file-download",
            kwargs={"token": token_obj.token},
        )

        full_url = request.build_absolute_uri(download_path)

        return Response({
            "download_url": full_url,
            "file_name": file_obj.file.name.split("/")[-1],
            "expires_at": token_obj.expires_at
        })
        
class FileDownloadView(APIView):
    """
     Handles secure file download using a valid download token.
    """
    permission_classes = [AllowAny]
    def get(self, request, token):    
        file_instance = FileService.validate_and_consume_token(token)

        file = file_instance.file

        if not file or not file.storage.exists(file.name):
            raise Http404("File not found.")

        return FileResponse(
            file.open("rb"),
            as_attachment=True,
            filename=file.name.split("/")[-1],
        )
        
class FileDeleteView(APIView):
    """Handles files deletion for the authenticated user.
    """
    permission_classes = [IsAuthenticated]

    def delete(self, request, pk):
        try:
            pk = uuid.UUID(pk)
        except ValueError:
            raise NotFound("File not found")
        file_obj = FileService.get_file_by_user(request.user, pk)
        FileService.delete_file(file_obj)
        return Response(
            {"message": "File deleted successfully"},
            status=status.HTTP_200_OK
        )