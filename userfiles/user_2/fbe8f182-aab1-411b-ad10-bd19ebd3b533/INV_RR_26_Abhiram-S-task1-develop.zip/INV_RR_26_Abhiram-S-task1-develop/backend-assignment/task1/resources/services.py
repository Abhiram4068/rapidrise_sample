from django.db import transaction, IntegrityError
from django.contrib.auth import get_user_model
from .models import Task,File, FileDownloadToken
from django.shortcuts import get_object_or_404
from django.http import Http404
import secrets
from django.utils import timezone
from datetime import timedelta
from rest_framework.exceptions import AuthenticationFailed, NotFound
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.exceptions import PermissionDenied

User = get_user_model()

class UserAuthService:
    """
    Service class that handles authentication-related business logic.
    Handles user registration, login, token generation, and logout.
    """
    @staticmethod
    def user_register(validated_data):
        try:
            with transaction.atomic():
                return User.objects.create_user(**validated_data)
        except IntegrityError:
            raise AuthenticationFailed(
                "Unable to create user right now. Please try again later."
            )
        
    @staticmethod
    def user_login(username: str, password: str):
        try:
            user=User.objects.get(username=username)
        except User.DoesNotExist:
            raise AuthenticationFailed("Invalid credentials")
        if not user.check_password(password):
            raise AuthenticationFailed("Invalid credentials")
        if not user.is_active:
            raise AuthenticationFailed("User account is disabled")
        refresh_token=RefreshToken.for_user(user)
        return {
        'user':user,
        'tokens':{
            'access':str(refresh_token.access_token),
            'refresh':str(refresh_token)
        }
    }
        
    @staticmethod
    def user_logout(refresh: str):
        try:
            token=RefreshToken(refresh)
            token.blacklist()
        except Exception:
            raise AuthenticationFailed("Invalid or expired refresh token")
        return True
    
    
class TaskService:    
    """
    Contains business logic for task operations.
    """
    @staticmethod
    def create_task(user, validated_data):
        return Task.objects.create(
            created_by=user,
            **validated_data
        )
        
    @staticmethod
    def task_by_user(user):
        tasks=Task.objects.filter(created_by=user).order_by('created_at')
        return tasks
    
    @staticmethod
    def task_detail(user, pk):
        # return get_object_or_404(Task, id=pk, created_by=user)
        try:
            return Task.objects.get(id=pk, created_by=user)
        except:
            raise NotFound("Task doesssnt exists!")
    
    @staticmethod
    def update_task(task, validated_data):
        for attr, value in validated_data.items():
            setattr(task, attr, value)
        task.save()
        return task
    
    @staticmethod
    def delete_task(task):
        task.delete()


class FileService:
    """
    Service layer for handling file-related business logic.
    """
    @staticmethod
    def upload_files(user, files):
        file_instances = []
        with transaction.atomic():
            for file_obj in files:
                file_instance = File.objects.create(
                    file=file_obj,
                    name=file_obj.name,
                    content_type=file_obj.content_type,
                    size=file_obj.size,
                    uploaded_by=user
                )
                file_instances.append(file_instance)

        return file_instances
    
    @staticmethod
    def get_file_by_user(user, pk):
        try:
           return File.objects.get(
            id=pk,
            uploaded_by=user
        )
        except File.DoesNotExist:
           raise NotFound("File not found")

    @staticmethod
    def list_files(user):
        files=File.objects.filter(uploaded_by=user).order_by('-created_at')
        return files
    @staticmethod
    def delete_file(file_obj):
        print("deleting file", file_obj.name)
        file_obj.delete()

    @staticmethod
    def generate_download_token(user, file_obj):
        token = secrets.token_urlsafe(32)

        expiry = timezone.now() + timedelta(minutes=5)

        return FileDownloadToken.objects.create(
            file=file_obj,
            user=user,
            token=token,
            expires_at=expiry
        )
    @staticmethod
    def validate_and_consume_token(token):
        try:
            token_obj = FileDownloadToken.objects.get(token=token)
        except FileDownloadToken.DoesNotExist:
            raise Http404("Invalid download link.")

        if timezone.now() > token_obj.expires_at:
            raise PermissionDenied("Download link expired.")

        if token_obj.is_accessed:
            raise PermissionDenied("Download link already used.")

        token_obj.is_accessed = True
        token_obj.save(update_fields=["is_accessed"])

        return token_obj.file