from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from resources.views import FileDeleteView, RegisterView, LoginView, LogoutView,TaskListCreateView,  TaskDetailView, TaskUpdateView, TaskDeleteView, FileListUploadView, FileDownloadView, FileLinkView

app_name='resources'

urlpatterns=[
    #auth urls
    path('auth/register/', RegisterView.as_view(), name='user-register'),
    path('auth/login/', LoginView.as_view(), name='user-login'),
    path('auth/refresh/', TokenRefreshView.as_view(), name="token_refresh"),
    path('auth/logout/', LogoutView.as_view(), name="user-logout"),
    
    #task crud
    path('task/', TaskListCreateView.as_view(), name='task-create-list'),
    path('task/<int:pk>/', TaskDetailView.as_view(), name='task-detail'),
    path('task/<int:pk>/update/', TaskUpdateView.as_view(), name='task-update'),
    path('task/<int:pk>/delete/', TaskDeleteView.as_view(), name='task-delete'),

    #file upload download api
    path('files/', FileListUploadView.as_view(), name='file-upload'),
    path('files/<str:pk>/delete/', FileDeleteView.as_view(), name='file-delete'),
    path("files/<str:pk>/token-generate/", FileLinkView.as_view(), name="file-link"),
    path("files/<str:token>/download/", FileDownloadView.as_view(), name="file-download"),
    
]