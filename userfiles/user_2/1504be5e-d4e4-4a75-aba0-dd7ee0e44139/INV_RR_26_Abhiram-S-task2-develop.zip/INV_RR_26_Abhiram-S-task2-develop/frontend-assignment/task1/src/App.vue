<template>
  <div class="app-container">
    <nav class="navbar" v-if="!isAuthPage">
      <div class="logo">Metric Calc</div>
      <div class="nav-links">
        <template v-if="isAuthenticated">
          <span class="nav-item">Welcome!</span>
          <button @click="logout" class="btn btn-outline">Logout</button>
        </template>
        <template v-else>
          <router-link to="/login" class="nav-item">Login</router-link>
          <router-link to="/register" class="btn btn-primary">Register</router-link>
        </template>
      </div>
    </nav>
    <main class="main-content">
      <router-view></router-view>
    </main>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useStore } from 'vuex';
import { useRoute, useRouter } from 'vue-router';

const store = useStore();
const route = useRoute();
const router = useRouter();

const isAuthenticated = computed(() => store.getters['auth/isAuthenticated']);
const isAuthPage = computed(() => ['Login', 'Register'].includes(route.name));

const logout = async () => {
  await store.dispatch('auth/logout');
  router.push('/login');
};
</script>

<style scoped>
/* NAVBAR COLORS: Grey/Black Theme */
.navbar {
  background-color: #111111; /* Deep Black */
  border-bottom: 1px solid #333333; /* Subtle Grey Border */
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  color: #ffffff;
}

.logo {
  font-weight: 800;
  font-size: 1.25rem;
  letter-spacing: 1px;
  color: #ffffff;
}

.nav-links {
  display: flex;
  align-items: center;
  gap: 1.5rem;
}

.nav-item {
  color: #a0a0a0; /* Grey text for links */
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 500;
}

.nav-item:hover {
  color: #ffffff;
}

/* Button Styling to match the Calculator theme */
.btn {
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  border: none;
  font-size: 0.85rem;
  transition: all 0.2s;
}

.btn-outline {
  background: transparent;
  border: 1px solid #444444;
  color: #ffffff;
}

.btn-outline:hover {
  background: #222222;
  border-color: #666666;
}

.btn-primary {
  background-color: #c0c0c0; /* Silver/Grey Button */
  color: #000000;
}

.btn-primary:hover {
  background-color: #ffffff;
}

.main-content {
  padding: 2rem;
}
</style>