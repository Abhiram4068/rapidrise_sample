<template>
  <div class="calculator-container">
    <div class="card silver-theme">
      <div class="calculator-header">
        <span class="brand-tag">Metric Calc</span>
        <h1 class="title">Precision Unit</h1>
      </div>
      
      <div class="display-screen" :class="{ 'is-loading': loading }">
        <div class="screen-label">Output Terminal</div>
        <div class="screen-main">
          <div v-if="result !== null" class="equation-text">
            {{ lastNum1 }} <span class="op-symbol">{{ getOperationSymbol(lastOperation) }}</span> {{ lastNum2 }}
          </div>
          <div class="value-text">
            <span v-if="loading" class="pulse">...</span>
            <span v-else-if="result !== null">{{ result }}</span>
            <span v-else class="placeholder-zero">0</span>
          </div>
        </div>
      </div>

      <div v-if="error" class="error-banner">
        {{ error }}
      </div>
      
      <div class="calculator-body">
        <div class="input-section">
          <label class="input-label">Input Parameters</label>
          <div class="form-row">
            <div class="input-wrapper">
              <input v-model.number="num1" type="number" class="silver-input" placeholder="0.00" />
              <span class="input-tag">VAL A</span>
            </div>
            <div class="input-wrapper">
              <input v-model.number="num2" type="number" class="silver-input" placeholder="0.00" />
              <span class="input-tag">VAL B</span>
            </div>
          </div>
        </div>
        
        <div class="calculator-actions">
          <button @click="calculate('add')" :disabled="loading" class="btn-calc">
            <span class="btn-icon">+</span>
            <span class="btn-text">Add</span>
          </button>
          <button @click="calculate('subtract')" :disabled="loading" class="btn-calc">
            <span class="btn-icon">−</span>
            <span class="btn-text">Sub</span>
          </button>
          <button @click="calculate('multiply')" :disabled="loading" class="btn-calc">
            <span class="btn-icon">×</span>
            <span class="btn-text">Mul</span>
          </button>
          <button @click="calculate('divide')" :disabled="loading" class="btn-calc">
            <span class="btn-icon">÷</span>
            <span class="btn-text">Div</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import api from '../api/axios';

const num1 = ref(null);
const num2 = ref(null);
const result = ref(null);
const loading = ref(false);
const error = ref('');

const lastNum1 = ref(null);
const lastNum2 = ref(null);
const lastOperation = ref(null);

const getOperationSymbol = (op) => {
  switch (op) {
    case 'add': return '+';
    case 'subtract': return '−';
    case 'multiply': return '×';
    case 'divide': return '÷';
    default: return '';
  }
};

const calculate = async (operation) => {
  if (num1.value === null || num2.value === null || num1.value === "" || num2.value === "") {
    error.value = 'Please enter both numbers.';
    return;
  }
  
  if (operation === 'divide' && parseFloat(num2.value) === 0) {
    error.value = 'Division by zero is not allowed.';
    return;
  }

  error.value = '';
  loading.value = true;
  result.value = null;

  try {
    const response = await api.get(`calculate/${operation}/${num1.value}/${num2.value}/`);
    
    if (typeof response.data === 'object' && response.data !== null) {
      result.value = Object.values(response.data)[0];
    } else {
      result.value = response.data;
    }
    
    lastNum1.value = num1.value;
    lastNum2.value = num2.value;
    lastOperation.value = operation;
  } catch (err) {
    console.error(err);
    error.value = err.response?.data?.error || err.response?.data?.detail || 'Calculation Error';
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.calculator-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 90vh;
  padding: 2rem;
}

/* Updated Card with Soft Neumorphism */
.card.silver-theme {
  background-color: #111111;
  border: 1px solid #222;
  box-shadow: 0 40px 100px rgba(0, 0, 0, 0.8);
  border-radius: 10px;
  padding: 2.5rem;
  color: #e0e0e0;
  max-width: 450px;
  width: 100%;
}

.calculator-header {
  text-align: center;
  margin-bottom: 2rem;
}

.brand-tag {
  color: #888;
  font-size: 0.7rem;
  text-transform: uppercase;
  letter-spacing: 4px;
  display: block;
  margin-bottom: 0.5rem;
}

.title {
  color: #ffffff;
  font-weight: 800;
  margin: 0;
  font-size: 1.5rem;
  letter-spacing: 1px;
}

/* Digital Screen Display */
.display-screen {
  background: #0a0a0a;
  border: 1px solid #333;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 2rem;
  position: relative;
  overflow: hidden;
  box-shadow: inset 0 2px 10px rgba(0,0,0,0.5);
}

.screen-label {
  font-size: 0.65rem;
  color: #555;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-bottom: 0.5rem;
}

.equation-text {
  font-size: 0.9rem;
  color: #888;
  font-family: 'Courier New', monospace;
  min-height: 1.2rem;
}

.value-text {
  font-size: 3rem;
  font-weight: 700;
  color: #ffffff;
  text-align: right;
  word-break: break-all;
  line-height: 1;
}

.placeholder-zero { opacity: 0.2; }

/* Inputs */
.input-label {
  font-size: 0.75rem;
  color: #888;
  display: block;
  margin-bottom: 0.75rem;
  text-transform: uppercase;
}

.form-row {
  display: flex;
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.input-wrapper {
  flex: 1;
  position: relative;
}

.silver-input {
  width: 100%;
  background: #1a1a1a;
  border: 1px solid #333;
  border-radius: 8px;
  padding: 1.2rem 0.5rem 0.5rem 0.5rem;
  color: #fff;
  font-size: 1.2rem;
  text-align: center;
  box-sizing: border-box;
}

.input-tag {
  position: absolute;
  top: 4px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 0.6rem;
  color: #555;
  font-weight: bold;
}

/* Calc Buttons */
.calculator-actions {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
}

.btn-calc {
  background: #c0c0c0;
  border: none;
  border-radius: 12px;
  padding: 1rem;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  transition: all 0.2s ease;
}

.btn-calc:hover:not(:disabled) {
  background: #ffffff;
  transform: translateY(-2px);
}

.btn-calc:active { transform: translateY(1px); }

.btn-calc:disabled {
  background: #333;
  color: #555;
  cursor: not-allowed;
}

.btn-icon {
  font-size: 1.5rem;
  font-weight: bold;
  color: #000;
}

.btn-text {
  font-size: 0.7rem;
  text-transform: uppercase;
  font-weight: 700;
  color: #000;
  margin-top: 2px;
}

/* Error UI */
.error-banner {
  background: rgba(255, 85, 85, 0.1);
  color: #ff5555;
  padding: 0.75rem;
  border-radius: 8px;
  font-size: 0.85rem;
  text-align: center;
  margin-bottom: 1.5rem;
  border: 1px solid rgba(255, 85, 85, 0.3);
}

.pulse {
  animation: pulse-anim 1.5s infinite;
}

@keyframes pulse-anim {
  0% { opacity: 1; }
  50% { opacity: 0.3; }
  100% { opacity: 1; }
}

/* Hide Spinners */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
</style>