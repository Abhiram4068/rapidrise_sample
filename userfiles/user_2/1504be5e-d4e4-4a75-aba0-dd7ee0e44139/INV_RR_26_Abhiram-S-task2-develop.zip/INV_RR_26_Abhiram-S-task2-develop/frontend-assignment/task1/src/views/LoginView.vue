<template>
  <div class="auth-container">
    <div class="card auth-form">
      <div class="auth-header">
        <h1 class="brand-title">Metric Calc</h1>
        <h2 class="welcome-text">Welcome back</h2>
        <p class="subtitle-text">Please enter your details to access your account.</p>
      </div>

      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input 
            v-model="form.username" 
            type="text" 
            class="form-input" 
            placeholder="Enter your username"
            required 
          />
        </div>
        
        <div class="form-group">
          <label class="form-label">Password</label>
          <input 
            v-model="form.password" 
            type="password" 
            class="form-input" 
            placeholder="••••••••"
            required 
          />
        </div>

        <p v-if="error" class="error-message">{{ error }}</p>

        <button :disabled="loading" type="submit" class="btn btn-primary">
          {{ loading ? 'Authenticating...' : 'Sign In' }}
        </button>

        <p class="footer-text">
          Don't have an account? 
          <router-link to="/register" class="register-link">Register</router-link>
        </p>
      </form>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue';
import { useStore } from 'vuex';
import { useRouter } from 'vue-router';

const store = useStore();
const router = useRouter();

const form = reactive({
  username: '',
  password: ''
});

const loading = ref(false);
const error = ref('');

const handleLogin = async () => {
  loading.value = true;
  error.value = '';
  try {
    await store.dispatch('auth/login', form);
    router.push('/');
  } catch (err) {
    error.value = err.response?.data?.detail || 'Login failed. Please check your credentials.';
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
/* Full page centering */
.auth-container {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}

/* RESTORED: Original Background Color */
:global(body) {
  background-color: #a45454ff !important;
  margin: 0;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
}

/* RESTORED: Original Card Colors with radius and padding improvements */
.card {
  background-color: #111111 !important;
  border: 1px solid #333333 !important;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3) !important;
  color: #e0e0e0 !important;
  border-radius: 10px !important;
  padding: 2.5rem !important;
  width: 100%;
  max-width: 400px;
}

/* Header Typography */
.auth-header {
  text-align: center;
  margin-bottom: 2rem;
}

.brand-title {
  color: #ffffff !important;
  font-size: 0.85rem !important;
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 700;
  margin-bottom: 0.5rem !important;
  opacity: 0.8;
}

.welcome-text {
  color: #ffffff !important;
  font-size: 1.75rem !important;
  font-weight: 600 !important;
  margin: 0 !important;
}

.subtitle-text {
  color: #a0a0a0;
  font-size: 0.9rem;
  margin-top: 0.5rem;
}

/* Form Styling with OG Colors */
.form-group {
  margin-bottom: 1.25rem;
}

.form-label {
  display: block;
  color: #a0a0a0 !important;
  font-size: 0.875rem;
  margin-bottom: 0.5rem;
}

.form-input {
  width: 100%;
  background-color: #222222 !important;
  border: 1px solid #444444 !important;
  color: #ffffff !important;
  padding: 0.75rem 1rem !important;
  border-radius: 6px !important;
  box-sizing: border-box;
}

.form-input:focus {
  outline: none;
  border-color: #c0c0c0 !important;
  box-shadow: 0 0 0 2px rgba(192, 192, 192, 0.2) !important;
}

/* RESTORED: Original Button Colors */
.btn-primary {
  width: 100%;
  padding: 0.8rem !important;
  background-color: #c0c0c0 !important;
  color: #000000 !important;
  border: none !important;
  border-radius: 6px !important;
  font-weight: 600 !important;
  font-size: 1rem;
  cursor: pointer;
  margin-top: 1rem;
}

.btn-primary:hover:not(:disabled) {
  background-color: #ffffff !important;
}

.btn-primary:disabled {
  background-color: #555555 !important;
  color: #aaaaaa !important;
}

/* Error Message OG Color */
.error-message {
  color: #ff5555 !important;
  font-size: 0.85rem;
  text-align: center;
  margin-bottom: 1rem;
}

.footer-text {
  text-align: center;
  margin-top: 1.5rem;
  color: #a0a0a0;
  font-size: 0.875rem;
}

.register-link {
  color: #c0c0c0;
  text-decoration: none;
  font-weight: 600;
}

.register-link:hover {
  text-decoration: underline;
}
</style>