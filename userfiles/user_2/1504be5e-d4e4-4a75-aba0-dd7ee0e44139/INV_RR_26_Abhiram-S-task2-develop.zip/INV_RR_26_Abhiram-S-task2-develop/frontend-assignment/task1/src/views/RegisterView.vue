<template>
  <div class="auth-container">
    <div class="card auth-form">
      <div class="auth-header">
        <h1 class="brand-title">Metric Calc</h1>
        <h2 class="welcome-text">Create Account</h2>
        <p class="subtitle-text">Join us to start managing your calculations.</p>
      </div>

      <form @submit.prevent="handleRegister">
        <div class="form-row">
          <div class="form-group flex-1">
            <label class="form-label">First Name</label>
            <input 
              v-model="form.first_name" 
              type="text" 
              class="form-input" 
              placeholder="John"
              required 
            />
          </div>
          <div class="form-group flex-1">
            <label class="form-label">Last Name</label>
            <input 
              v-model="form.last_name" 
              type="text" 
              class="form-input" 
              placeholder="Doe"
              required 
            />
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Username</label>
          <input 
            v-model="form.username" 
            type="text" 
            class="form-input" 
            placeholder="johndoe123"
            required 
          />
        </div>

        <div class="form-row">
          <div class="form-group flex-1">
            <label class="form-label">Password</label>
            <input 
              v-model="form.password" 
              type="password" 
              class="form-input" 
              placeholder="••••••••"
              required 
            />
          </div>
          <div class="form-group flex-1">
            <label class="form-label">Confirm</label>
            <input 
              v-model="form.confirm_password" 
              type="password" 
              class="form-input" 
              placeholder="••••••••"
              required 
            />
          </div>
        </div>

        <p v-if="error" class="error-message">{{ error }}</p>

        <button :disabled="loading" type="submit" class="btn btn-primary">
          {{ loading ? 'Creating Account...' : 'Register' }}
        </button>

        <p class="footer-text">
          Already have an account? 
          <router-link to="/login" class="login-link">Login</router-link>
        </p>
      </form>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue';
import { useStore } from 'vuex';
import { useRouter } from 'vue-router';

const store = useStore();
const router = useRouter();

const form = reactive({
  first_name: '',
  last_name: '',
  username: '',
  password: '',
  confirm_password: ''
});

const loading = ref(false);
const error = ref('');

const validatePassword = (password) => {
  if (password.length < 8) return "Password must be at least 8 characters long.";
  if (!/[a-z]/.test(password)) return "Password must contain at least one lowercase letter.";
  if (!/[A-Z]/.test(password)) return "Password must contain at least one uppercase letter.";
  if (!/[!@#$%^&*()]/.test(password)) return "Password must contain at least one special character (!@#$%^&*()).";
  return null;
};

const handleRegister = async () => {
  error.value = '';
  
  if (form.password !== form.confirm_password) {
    error.value = "Passwords do not match.";
    return;
  }

  const passwordError = validatePassword(form.password);
  if (passwordError) {
    error.value = passwordError;
    return;
  }

  loading.value = true;
  try {
    await store.dispatch('auth/register', form);
    router.push('/login');
  } catch (err) {
    if (typeof err.response?.data === 'object' && err.response.data.username) {
        error.value = 'Username already exists.';
    } else if (err.response?.data?.password) {
        error.value = err.response.data.password[0];
    } else {
        error.value = err.response?.data?.detail || 'Registration failed. Please check your inputs.';
    }
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
/* Full page centering */
.auth-container {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 20px;
}

/* RESTORED: Original Background Color */
:global(body) {
  background-color: #a45454ff !important;
  margin: 0;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
}

/* RESTORED: Original Card Colors with Radius and Width */
.card {
  background-color: #111111 !important;
  border: 1px solid #333333 !important;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3) !important;
  color: #e0e0e0 !important;
  border-radius: 12px !important;
  padding: 2.5rem !important;
  width: 100%;
  max-width: 480px; /* Slightly wider for the two-column rows */
}

/* Header Typography */
.auth-header {
  text-align: center;
  margin-bottom: 2rem;
}

.brand-title {
  color: #ffffff !important;
  font-size: 0.85rem !important;
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 700;
  margin-bottom: 0.5rem !important;
  opacity: 0.7;
}

.welcome-text {
  color: #ffffff !important;
  font-size: 1.75rem !important;
  font-weight: 600 !important;
  margin: 0 !important;
}

.subtitle-text {
  color: #a0a0a0;
  font-size: 0.9rem;
  margin-top: 0.5rem;
}

/* Form Layout */
.form-row {
  display: flex;
  gap: 1rem;
}

.flex-1 {
  flex: 1;
}

.form-group {
  margin-bottom: 1.25rem;
}

.form-label {
  display: block;
  color: #a0a0a0 !important;
  font-size: 0.8rem;
  font-weight: 500;
  margin-bottom: 0.5rem;
}

/* Inputs */
.form-input {
  width: 100%;
  background-color: #222222 !important;
  border: 1px solid #444444 !important;
  color: #ffffff !important;
  padding: 0.75rem 1rem !important;
  border-radius: 8px !important;
  box-sizing: border-box;
  font-size: 0.9rem;
  transition: all 0.2s ease;
}

.form-input:focus {
  outline: none;
  border-color: #c0c0c0 !important;
  box-shadow: 0 0 0 2px rgba(192, 192, 192, 0.1) !important;
}

/* Button */
.btn-primary {
  width: 100%;
  padding: 0.8rem !important;
  background-color: #c0c0c0 !important;
  color: #000000 !important;
  border: none !important;
  border-radius: 8px !important;
  font-weight: 600 !important;
  font-size: 1rem;
  cursor: pointer;
  margin-top: 1rem;
  transition: background-color 0.2s;
}

.btn-primary:hover:not(:disabled) {
  background-color: #ffffff !important;
}

.btn-primary:disabled {
  background-color: #555555 !important;
  color: #aaaaaa !important;
}

/* Footer & Error */
.error-message {
  color: #ff5555 !important;
  font-size: 0.8rem;
  text-align: center;
  margin: 0.5rem 0 1rem 0;
  line-height: 1.4;
}

.footer-text {
  text-align: center;
  margin-top: 1.5rem;
  color: #a0a0a0;
  font-size: 0.875rem;
}

.login-link {
  color: #ffffff;
  text-decoration: none;
  font-weight: 600;
}

.login-link:hover {
  text-decoration: underline;
}
</style>