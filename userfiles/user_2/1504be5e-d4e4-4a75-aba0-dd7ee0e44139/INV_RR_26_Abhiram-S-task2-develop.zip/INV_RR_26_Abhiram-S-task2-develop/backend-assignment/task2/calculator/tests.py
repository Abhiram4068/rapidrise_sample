from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth import get_user_model

User = get_user_model()


class AuthTests(APITestCase):

    def setUp(self):
        self.register_url = reverse("calculator:user-register")
        self.login_url = reverse("calculator:user-login")
        self.logout_url = reverse("calculator:user-logout")

        self.user_data = {
            "username": "testuser",
            "password": "StrongPass123",
            "confirm_password": "StrongPass123",
            "first_name": "John",
            "last_name": "Doe"
        }

    def test_user_registration_success(self):
        response = self.client.post(self.register_url, self.user_data)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(User.objects.filter(username="testuser").exists())

    def test_user_registration_duplicate_username(self):
        User.objects.create_user(username="testuser", password="StrongPass123")

        response = self.client.post(self.register_url, self.user_data)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_user_registration_password_mismatch(self):
        data = self.user_data.copy()
        data["confirm_password"] = "WrongPass123"

        response = self.client.post(self.register_url, data)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_user_login_success(self):
        User.objects.create_user(username="testuser", password="StrongPass123")

        response = self.client.post(self.login_url, {
            "username": "testuser",
            "password": "StrongPass123"
        })

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("tokens", response.data)

    def test_user_login_invalid_credentials(self):
        User.objects.create_user(username="testuser", password="StrongPass123")

        response = self.client.post(self.login_url, {
            "username": "testuser",
            "password": "wrongpass"
        })

        self.assertIn(response.status_code, [401, 403])

    def test_user_logout_success(self):
        user = User.objects.create_user(username="testuser", password="StrongPass123")

        login = self.client.post(self.login_url, {
            "username": "testuser",
            "password": "StrongPass123"
        })

        refresh = login.data["tokens"]["refresh"]

        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {login.data['tokens']['access']}")

        response = self.client.post(self.logout_url, {"refresh": refresh})

        self.assertEqual(response.status_code, status.HTTP_200_OK)


class ArithmeticTests(APITestCase):

    def setUp(self):
        self.user = User.objects.create_user(
            username="testuser",
            password="StrongPass123"
        )

        login_url = reverse("calculator:user-login")

        login = self.client.post(login_url, {
            "username": "testuser",
            "password": "StrongPass123"
        })

        access = login.data["tokens"]["access"]

        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {access}")

    def test_add(self):
        url = reverse("calculator:calculate-add", args=[10, 5])
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["Result"], 15)

    def test_subtract(self):
        url = reverse("calculator:calculate-subtract", args=[10, 5])
        response = self.client.get(url)

        self.assertEqual(response.data["Result"], 5)

    def test_multiply(self):
        url = reverse("calculator:calculate-multiply", args=[10, 5])
        response = self.client.get(url)

        self.assertEqual(response.data["Result"], 50)

    def test_divide(self):
        url = reverse("calculator:calculate-divide", args=[10, 2])
        response = self.client.get(url)

        self.assertEqual(response.data["Result"], 5)

    def test_divide_by_zero(self):
        url = reverse("calculator:calculate-divide", args=[10, 0])
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)