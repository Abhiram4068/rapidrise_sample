from rest_framework.views import APIView
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from .serializers import RegisterSerializer, LoginSerializer, LogoutSerializer
from .services import UserAuthService, ArithmeticService


class RegisterView(APIView):
    """
        API view for handling user registration.
    """
    authentication_classes=[]
    permission_classes=[AllowAny]
    
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = UserAuthService.user_register(serializer.validated_data)

        return Response(
            {
                "message": "User registered successfully",
                "user_id": user.id
            },
            status=status.HTTP_201_CREATED
        )



class LoginView(APIView):
    """
        API view for user authentication.
    """
    permission_classes=[AllowAny]
    authentication_classes=[]
    
    def post(self, request):
        serializer=LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        result=UserAuthService.user_login(
            serializer.validated_data['username'],
            serializer.validated_data['password']
        )

        user=result['user']
        tokens=result['tokens']
        return Response(
            {'message':'Login successful',
             'user':{
                 'id':user.id,
                 'first_name':user.first_name
             },
             'tokens':tokens
             },
            
            status=status.HTTP_200_OK
        )
        
class LogoutView(APIView):
    """
        API view for logging out authenticated users.
    """

    permission_classes=[IsAuthenticated]
    
    def post(self, request):
        serializer=LogoutSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        refresh=serializer.validated_data['refresh']
        UserAuthService.user_logout(refresh)
        return Response(
            {'message':'Logout successful'},
             status=status.HTTP_200_OK
        )
    
class AddView(APIView):
    """
    API endpoint to add two numbers.
    Accepts two numbers from the URL and returns their sum.
    """
    permission_classes=[IsAuthenticated]
    
    def get(self, request, num1, num2):
        try:
            result = ArithmeticService.add(num1, num2)
            return Response({'Result': result}, status=status.HTTP_200_OK)
        except TypeError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class SubtractView(APIView):
    """
    API endpoint to subtract two numbers.
    Accepts two numbers from the URL and returns their difference.
    """
    permission_classes=[IsAuthenticated]
    
    def get(self, request, num1, num2):
        try:
            result = ArithmeticService.subtract(num1, num2)
            return Response({'Result': result}, status=status.HTTP_200_OK)
        except TypeError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class MultiplyView(APIView):
    """
    API endpoint to multiply two numbers.
    Accepts two numbers from the URL and returns their product.
    """
    permission_classes=[IsAuthenticated]
    
    def get(self, request, num1, num2):
        try:
            result = ArithmeticService.multiply(num1, num2)
            return Response({'Result': result}, status=status.HTTP_200_OK)
        except TypeError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class DivideView(APIView):
    """
    API endpoint to divide two numbers.
    Accepts two numbers from the URL and returns the division result.
    Returns an error if division by zero occurs.
    """
    permission_classes=[IsAuthenticated]
    
    def get(self, request, num1, num2):
        try:
            result = ArithmeticService.divide(num1, num2)
            return Response({'Result': result}, status=status.HTTP_200_OK)
        except (TypeError, ValueError) as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)