from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
User=get_user_model()
import re
class RegisterSerializer(serializers.ModelSerializer):
    """
    Serializer for registering a new user,
    Handles validation
    """
    confirm_password=serializers.CharField(write_only=True, min_length=8)
    class Meta:
        model=User
        fields=[
            'username',
            'password',
            'confirm_password',
            'first_name',
            'last_name'
        ]
        extra_kwargs={
            'password':{'write_only':True, 'min_length':8},
            'last_name':{'required':False},
        }
    def validate_username(self, value):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError(
                ('Username already exists!')
            )
        return value

    def validate_password(self, value):
        if not re.search(r"[a-z]", value):
            raise serializers.ValidationError(
                "Password must contain at least one lowercase letter."
            )

        if not re.search(r"[A-Z]", value):
            raise serializers.ValidationError(
                "Password must contain at least one uppercase letter."
            )

        if not re.search(r"[!@#$%^&*()]", value):
            raise serializers.ValidationError(
                "Password must contain at least one special character (!@#$%^&*())."
            )

        return value
    def validate(self, attrs):
        password=attrs.get('password')
        confirm_password=attrs.get('confirm_password')
        if password!=confirm_password:
            raise serializers.ValidationError(
                {'confirm_password':'Passwords do not match'}
            )
        validate_password(password)
        attrs.pop('confirm_password')
        return attrs
    
    
class LoginSerializer(serializers.Serializer):
    """
     Serializer for user login,
      Validates the username and password
    """
    username=serializers.CharField()
    password=serializers.CharField(write_only=True)
    
class LogoutSerializer(serializers.Serializer):
    """
    Serializer for user logout,
    Accepts the refresh token that will be blacklisted
    """
    refresh = serializers.CharField()