
from django.db import transaction, IntegrityError
from django.contrib.auth import get_user_model
from rest_framework.exceptions import AuthenticationFailed
from rest_framework_simplejwt.tokens import RefreshToken

User = get_user_model()


class UserAuthService:
    """
    Service class that handles authentication-related business logic.
    Handles user registration, login, token generation, and logout.
    """
    @staticmethod
    def user_register(validated_data):
        try:
            with transaction.atomic():
                return User.objects.create_user(**validated_data)
        except IntegrityError:
            raise AuthenticationFailed(
                "Unable to create user right now. Please try again later."
            )
        
    @staticmethod
    def user_login(username: str, password: str):
        try:
            user=User.objects.get(username=username)
        except User.DoesNotExist:
            raise AuthenticationFailed("Invalid credentials")
        if not user.check_password(password):
            raise AuthenticationFailed("Invalid credentials")
        if not user.is_active:
            raise AuthenticationFailed("User account is disabled")
        refresh_token=RefreshToken.for_user(user)
        return {
        'user':user,
        'tokens':{
            'access':str(refresh_token.access_token),
            'refresh':str(refresh_token)
        }
    }
        
    @staticmethod
    def user_logout(refresh: str):
        try:
            token=RefreshToken(refresh)
            token.blacklist()
        except Exception:
            raise AuthenticationFailed("Invalid or expired refresh token")
        return True
    
class ArithmeticService:
    """
    Service class responsible for performing basic arithmetic operations.
    This class contains static methods to handle addition, subtraction,
    multiplication, and division of two numbers.
    """
    @staticmethod
    def add(num1, num2):
        try:
            num1 = float(num1)
            num2 = float(num2)
        except (ValueError, TypeError):
            raise TypeError("Inputs must be valid numbers.")
        
        return num1 + num2

    @staticmethod
    def subtract(num1, num2):
        try:
            num1 = float(num1)
            num2 = float(num2)
        except (ValueError, TypeError):
            raise TypeError("Inputs must be valid numbers.")
        
        return num1 - num2

    @staticmethod
    def multiply(num1, num2):
        try:
            num1 = float(num1)
            num2 = float(num2)
        except (ValueError, TypeError):
            raise TypeError("Inputs must be valid numbers.")
        
        return num1 * num2

    @staticmethod
    def divide(num1, num2):
        try:
            num1 = float(num1)
            num2 = float(num2)
        except (ValueError, TypeError):
            raise TypeError("Inputs must be valid numbers.")

        if num2 == 0:
            raise ValueError("Division by zero is not allowed.")

        return num1 / num2