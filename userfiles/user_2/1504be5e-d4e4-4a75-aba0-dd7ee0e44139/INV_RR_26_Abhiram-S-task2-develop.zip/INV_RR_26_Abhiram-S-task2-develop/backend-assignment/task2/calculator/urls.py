 
from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import RegisterView, LoginView, LogoutView, AddView, SubtractView, MultiplyView, DivideView

app_name='calculator'

urlpatterns=[
   #auth urls
    path('auth/register/', RegisterView.as_view(), name='user-register'),
    path('auth/login/', LoginView.as_view(), name='user-login'),
    path('auth/refresh/', TokenRefreshView.as_view(), name="token_refresh"),
    path('auth/logout/', LogoutView.as_view(), name="user-logout"),

    # urls for arithmetic operations
    path('calculate/add/<str:num1>/<str:num2>/', AddView.as_view(), name='calculate-add'),
    path('calculate/subtract/<str:num1>/<str:num2>/', SubtractView.as_view(), name='calculate-subtract'),
    path('calculate/multiply/<str:num1>/<str:num2>/', MultiplyView.as_view(), name='calculate-multiply'),
    path('calculate/divide/<str:num1>/<str:num2>/', DivideView.as_view(), name='calculate-divide'),
]