# TASK-2 ASSIGNMENT – Arithmetic API with JWT Authentication

This project implements a simple **Arithmetic Operation API** built using **Django REST Framework**.  
The API allows authenticated users to perform basic arithmetic operations:

- Addition
- Subtraction
- Multiplication
- Division

Authentication is handled using **JWT (JSON Web Tokens)** to ensure that only authenticated users can access the arithmetic endpoints.

---

# Features

### Authentication
- User registration
- Login using JWT authentication
- Token refresh
- Logout with refresh token blacklist

### Arithmetic Operations
Authenticated users can perform the following operations:

- Addition
- Subtraction
- Multiplication
- Division

Each endpoint takes **two numbers as input parameters** and returns the calculated result.

---

# Tech Stack

- Python
- Django
- Django REST Framework
- SimpleJWT
- SQLite

---

# Project Structure

```
backend-assignment/
|
├── task1
│
├── task2/
│   │
│   ├── config/                # Django project configuration
│   │   ├── settings.py
│   │   └── urls.py
│   │
│   ├── calculator/            # Arithmetic operations application
│   │   ├── models.py
│   │   ├── serializers.py
│   │   ├── views.py
│   │   ├── services.py
│   │   └── urls.py
│   │
│   ├── manage.py
│   ├── db.sqlite3
│   ├── .env
│   ├── requirements.txt
│   └── venv/
│
└── README.md
```

---

# Installation Guide

## 1. Clone the Repository

```bash
git clone <repository-url>
cd backend-assignment/task2
```

---

# 2. Create Virtual Environment

```bash
python -m venv venv
```

Activate the environment.

Linux / Mac

```bash
source venv/bin/activate
```

Windows

```bash
venv\Scripts\activate
```

---

# 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

# 4. Setup Environment Variables

Create a `.env` file inside **task2**.

Example:

```
SECRET_KEY=your_secret_key
DEBUG=True

ACCESS_TOKEN_LIFETIME=15
REFRESH_TOKEN_LIFETIME=7
```

---

# 5. Apply Migrations

```bash
python manage.py migrate
```

---

# 6. Run the Server

```bash
python manage.py runserver
```

Server will start at:

```
http://127.0.0.1:8000
```

---

# Authentication Flow

```
User Login
   ↓
Server validates credentials
   ↓
Access Token + Refresh Token generated
   ↓
Client sends Access Token in Authorization header
   ↓
Protected APIs accessed
```

Example Authorization header:

```
Authorization: Bearer <access_token>
```

---

# API Endpoints

Base URL

```
/api/
```

---

# Authentication APIs

```
POST /api/auth/register/
POST /api/auth/login/
POST /api/auth/refresh/
POST /api/auth/logout/
```

| Endpoint | Description |
|--------|-------------|
| Register | Creates a new user |
| Login | Returns access and refresh tokens |
| Refresh | Generates new access token |
| Logout | Blacklists refresh token |

---

# Arithmetic Operation APIs

```
GET /api/calculate/add/{num1}/{num2}/
GET /api/calculate/subtract/{num1}/{num2}/
GET /api/calculate/multiply/{num1}/{num2}/
GET /api/calculate/divide/{num1}/{num2}/
```

| Endpoint | Description |
|--------|-------------|
| Add | Returns the sum of two numbers |
| Subtract | Returns the difference of two numbers |
| Multiply | Returns the product of two numbers |
| Divide | Returns the division result of two numbers |

---

# Example Requests

### Addition

```
GET /api/calculate/add/10/5/
```

Response

```
{
  "result": 15
}
```

---

### Division

```
GET /api/calculate/divide/20/4/
```

Response

```
{
  "result": 5
}
```

---

# Error Handling

Example division by zero:

```
GET /api/calculate/divide/10/0/
```

Response

```
{
  "error": "Division by zero is not allowed"
}
```

---

# Running Tests

```
python manage.py test
```

---

# Environment Configuration

The project uses **python-dotenv** to manage environment variables.

Sensitive configurations such as:

- SECRET_KEY
- DEBUG
- JWT token lifetimes

are stored in `.env` instead of being hardcoded in `settings.py`.

---

# Author

Abhiram S